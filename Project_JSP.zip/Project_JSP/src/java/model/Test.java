/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author surakitisopontanapat
 */
public class Test {
    public static void main(String[] args) {
//        Member rs = new Member();
//        rs.Register("eiei sung", "kawaei", "1234", 123123, 12, "081111", "asdasd@hi", "male", 177, 50);
      // Instantiate a Date object
//      Date date = new Date();
//       display time and date using toString()
//      System.out.println(date.toString());
//      
//       Date dNow = new Date( );
//      SimpleDateFormat ft = new SimpleDateFormat ("dd-MM-YYYY");
//      System.out.println("Current Date: " + ft.format(dNow));

       
          
            
    }
}
